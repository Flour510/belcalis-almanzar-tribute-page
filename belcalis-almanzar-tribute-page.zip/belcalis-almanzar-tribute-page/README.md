# Belcalis Almanzar Tribute Page

A Pen created on CodePen.io. Original URL: [https://codepen.io/flour_/pen/RwjPKxE](https://codepen.io/flour_/pen/RwjPKxE).

